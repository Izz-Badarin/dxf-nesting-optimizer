# Najjar Pro — gadget core (v0.10.0)

> **Every shop has a carpenter. Now it has Najjar Pro.**
> كُلّ ورشة عندها نجّار — هلق كمان عندها Najjar Pro

The headless Lua core of the **Najjar Pro** parametric cabinet builder —
the product planned in [`docs/vcarve-gadget-product-plan.md`](../docs/vcarve-gadget-product-plan.md).
**👉 New here? Read [`TESTING.md`](TESTING.md) — test everything on your
shop PC in 5 minutes, no VCarve needed.**

This code runs **without VCarve installed**; the thin Vectric API layer
(dialogs + drawing into a job) plugs on top once development licenses
arrive.

## What it does (v0.3)

You describe cabinets as **data** — and the shop's own configuration is
data too:

```json
{ "project": "kitchen-mixed",
  "units": "mm",
  "panel_material": { "thickness": 18.0, "name": "ply-18" },
  "sheet": { "width": 1220, "height": 2440 },
  "materials": { "shelf": { "thickness": 16.0, "name": "ply-16" } },
  "fronts": { "style": "full_overlay", "reveal": 3.0, "edge": 2.0 },
  "cabinets": [{
    "id": "K1", "width": 900, "height": 900, "depth": 550,
    "construction": { "back": { "type": "grooved", "thickness": 9 } },
    "zones": [
      { "type": "door", "from": 0, "to": 700, "doors": { "count": 2 },
        "dividers": [{ "at": 300 }],
        "shelves": { "count": 2, "adjustable": true } },
      { "type": "drawers", "from": 700, "to": 900,
        "drawers": { "count": 2, "box": true } }
    ],
    "hardware": { "connector": "cabineo_12", "shelf_pins": "shelf_pin_5",
                  "hinges": "hinge_cup_35", "led_channel": "led_channel_8x8" } }] }
```

and the core produces, fully dimensioned and deterministic:

- **Panels**: sides, bottom, top, grooved/nailed back — thickness and
  material **per role** (side/bottom/top/shelf/divider/door/front/drawer)
- **Classic euro construction**: with a grooved back, bottom/top/dividers
  are pulled forward of the back zone so the full-height back rides the
  side grooves
- **Zones**: `open` / `door` / `drawers` — per-zone shelves, door counts,
  drawer counts
- **Dividers** inside zones: per-bay shelf pieces, connector machining on
  the divider AND on the horizontal panels at the divider line; bays and
  connections computed automatically; `field-connect` notes where a
  divider meets no panel
- **Drawer boxes** (`"box": true`): sides, front/back, bottom — height,
  clearance, depth and bottom thickness all parametric; bottom joinery
  `"lay-in"` (default) or `"grooved"` (BOX_GROOVE machining on sides+FB,
  bottom sized into the grooves)
- **Drawer slide locking patterns** from the hardware library
  (`"slides": "slide_undermount"`): rear hole + front slot on the box
  sides, brand positions parametric; side-mount slides are screw-on (no
  machining) and the library says so
- **Divider pin columns**: dividers in adjustable-shelf zones get the
  system-32 ladder on BOTH faces — face B is pre-mirrored onto the
  `DRILL5_SHELF_FLIP` layer with a flip note (flip about the short axis)
- **Drawer-box corner joinery** from the library
  (`"joinery": "corner_dowel_8"` or `"corner_rafix_15"`): face holes on
  the box sides as `DRILL_DOWEL` geometry; the mating edge holes on the
  front/back panels become an `edge-drill` BOM note (horizontal drill)
- **Edge banding** per role (`edge_banding: {"shelf": "front", ...}`) —
  defaults for every part role, user overrides, and a translated BOM
  column (EN / HE / AR)
- **Multi-cabinet projects**: a whole kitchen in one spec — identical
  cabinets merge into single BOM rows with doubled quantities, one
  project-wide cut list and sheet estimate (see `kitchen-job.json`)
- **Vectric adapter** (`vectric.lua`): the core renders through a
  backend — mock-tested today, the real VCarve/Aspire job backend plugs
  into the same interface in v0.6 without touching the core
- **Doors & drawer fronts** with full-overlay reveal math; doors carry
  their hinge side
- **System-32 shelf pin ladders** (2 columns, 32 mm pitch)
- **Cabineo 12 connector machining** (Ø15 pocket + Ø5 drill) on sides,
  dividers and horizontal panels — all from library data
- **Cup hinge placement** on doors (Ø35 + Ø5.5 pattern, count by height,
  mirrored pairs)
- **LED channel groove** on the top panel underside (flip note in the BOM)
- **BOM** (CSV, UTF-8 + BOM, EN/HE/AR, **mm or inch display**)
- **DXF R12** with one layer per machining operation
- **SVG preview** for humans
- **job.json** — the structured bridge to the nesting optimizer in this repo

### The shop's own baseline: `defaults.json`

Copy `defaults.json.example` to `defaults.json` next to `main.lua` and put
your shop's standard there — panel thickness & material, sheet/board size,
front reveals. **Every spec is merged over it** (the spec wins), so a
4-line spec inherits your whole shop configuration. `defaults.json` is
gitignored; each machine keeps its own.

## 3D viewer, dimension check & import (v0.7) ✨

Every run now produces **`<project>_viewer.html`** — a fully
self-contained interactive 3D view (no internet needed, works offline
in any browser):

- **drag to rotate**, scroll to zoom, Front / Isometric / Top buttons
- **Explode slider** — pull the cabinet apart: sides out, back off,
  doors and drawer boxes forward, every drawer on its own step
- **clickable parts list** with real cut dimensions and edge-banding notes
- **dimension check panel** — the same checks that print to the console:
  part bigger than the board (error), fits-only-rotated (info), doors
  too narrow, drawer fronts too low, drawer box taller than its front
  opening, hinge count per door height, back groove over half the
  panel thickness, unusual shelf setback

**Bring configurations from other apps** (`convert.lua`):

```
lua convert.lua foreign-config.json my-spec.json --map importers/generic_flat.json
lua convert.lua cutlist.csv            my-spec.json
lua main.lua my-spec.json out en
```

A *map file* (`importers/*.json`) lists the field-name aliases of the
other app — new app, new map, **no code changes**. A CSV cut list
(English / Hebrew / Arabic headers) becomes a loose-parts project that
runs through the same pipeline: BOM, DXF, preview, 3D viewer.

## Sheet nesting & cost estimate (v0.8) 📦

The core now **packs parts onto real boards** (not just an area estimate):
saw kerf and trim margins honoured, grain-aware (doors, fronts and plinths
never rotate), one SVG per board with labels, dimensions and grain arrows:

```
Nesting: 5 sheet(s), 75% of the boards used
Estimated cost: 858.83 ILS
```

- `sheet.kerf` / `sheet.margin` — user settings (mm)
- utilization %, sheet count and the full placement layout land in `job.json`
- **cost estimate**: boards (nested count x price/m2) + edge-banding metres +
  counted hardware units x unit price — in the console, the BOM CSV and
  `job.json`. **Every price is editable**: the `pricing` block in your spec
  or `defaults.json`, and the `price` field inside each hardware JSON.
  Shipped values are placeholders — set your real numbers once.

**Plinth / toe-kick** (every euro base cabinet has one):

```json
"construction": { "plinth": { "height": 100, "recess": 50, "thickness": 16 } }
```

The plinth becomes its own part (BOM note carries the recess), the 3D body
sits on it, and it explodes downward in the viewer. See
`templates/base-plinth.json`.

**Hardening**: hostile JSON (depth-bombed), semicolon/tab CSVs with decimal
commas, and fuzzed specs all fail cleanly with localized messages; a parity
test guarantees every UI string exists in English, Hebrew AND Arabic.

## The VCarve / Aspire gadget shell (v0.10) 🎯

The installable gadget is ready: **`release/NajjarPro.vgadget`** (or build
it yourself: `sh tools/package-gadget.sh` / `tools/package-gadget.ps1`).

**v0.10 — the job becomes the cut file:** with *Draw nested boards*
(default on) the gadget draws each board into the job — parts at their
nested positions, rotated features rotated along (never mirrored), part
labels on `ETCH`, board boundaries on `CNC_BOUNDARY`. Add your toolpath
templates and post; no manual nesting inside VCarve. A first-run
self-check verifies the VCarve API surface and reports anything missing
in one clear message.

**v0.9 — the full wizard, three pages, everything user-enterable:**

1. **Cabinet** — name, ID, width/height/depth, panel thickness, units,
   back construction, language
2. **Interior** — shelves (+adjustable), doors (count), drawer zone
   (count, boxed drawers), plinth/toe-kick (height)
3. **Hardware & boards** — connectors, shelf pins, hinges, board size,
   saw kerf, trim margin, board price/m², edge price/m, currency

**One-click toolpaths:** save one toolpath template per layer into the
gadget's `toolpaths/` folder (`CUT.ToolpathTemplate`,
`POCKET_CABINEO.ToolpathTemplate`, … — see `toolpaths/README.md`); the
gadget loads them after drawing and the toolpath list fills itself.
The API (`ToolpathManager():LoadToolpathTemplate(path)`) is verified
against public Vectric gadgets.

**Install (VCarve Pro / Aspire 11+):**

1. Download `NajjarPro.vgadget` from this repository (`gadget/release/`)
2. In VCarve/Aspire: **Gadgets → Install New Gadget…** → pick the file
3. Restart the program, then: **Gadgets → Najjar Pro**
4. Fill the three wizard pages → **OK** on the last page
5. Every panel appears in the job on the layer contract; BOM, DXF,
   nesting sheets, the 3D viewer and the cost estimate land in the
   gadget's `out/` folder; toolpath templates (if present) load
   automatically

The shell (`vcarve/Najjar_Pro.lua`) loads the *same headless core* through
`package.preload`, renders through the backend adapter
(`vcarve/najjar_backend.lua`), and follows the API patterns verified from
public Vectric gadgets (`HTML_Dialog`, `Contour/AppendPoint/LineTo/ArcTo`,
`LayerManager:GetLayerWithName`, `AddObject`, `ToolpathManager`).
The first lines of both shell files carry the required
`-- VECTRIC LUA SCRIPT` marker.

⚠️ the API usage mirrors real public gadgets, but it has **not yet run
inside a live VCarve** — that first-run test happens the moment a VCarve
Pro license is available. The test-suite covers everything short of it
(1400 assertions: syntax, wizard page/field consistency, spec assembly,
mock + board render through fake SDKs, 3D model, checks, import, viewer,
nesting, cost, fuzz).

The installable gadget is ready: **`release/NajjarPro.vgadget`** (or build
it yourself: `sh tools/package-gadget.sh` / `tools/package-gadget.ps1`).

**Install (VCarve Pro / Aspire 11+):**

1. Download `NajjarPro.vgadget` from this repository (`gadget/release/`)
2. In VCarve/Aspire: **Gadgets → Install New Gadget…** → pick the file
3. Restart the program, then: **Gadgets → Najjar Pro**
4. Fill the wizard (dimensions → construction → hardware) → **OK**
5. Every panel appears in the job on the layer contract
   (`CUT`, `DRILL5_SHELF`, `POCKET_CABINEO`, `DRILL_CABINEO`,
   `DRILL_HINGE`, `ETCH`); a BOM + DXF land in the gadget's `out/` folder

The shell (`vcarve/Najjar_Pro.lua`) loads the *same headless core* through
`package.preload`, renders through the backend adapter
(`vcarve/najjar_backend.lua`), and follows the API patterns verified from
public Vectric gadgets (`HTML_Dialog`, `Contour/AppendPoint/LineTo/ArcTo`,
`LayerManager:GetLayerWithName`, `AddObject`). The first lines of both
shell files carry the required `-- VECTRIC LUA SCRIPT` marker.

⚠️ v0.6 is the shell spike: the API usage mirrors real public gadgets, but
it has **not yet run inside a live VCarve** — that first-run test happens
the moment a VCarve Pro license is available. The test-suite already
covers everything short of it (1246 assertions: syntax, dialog/field
consistency, spec assembly, mock-render through a fake SDK, 3D model,
checks, import, viewer, nesting, nesting, cost, fuzz). The shell writes the 3D
viewer, nesting sheets and dimension checks next to the BOM/DXF in the
gadget's `out/` folder.

## Run it (headless)

Requires any Lua 5.1+ (Lua 5.4 recommended). No other dependencies.

```bash
cd gadget
lua main.lua templates/kitchen-mixed.json out en      # English
lua main.lua templates/wardrobe-zones.json out ar     # العربية
lua main.lua templates/euro-base-900.json out he      # עברית
```

(No Lua installed? `sh ../tools/build-lua.sh` builds one in ~10 seconds.)

Outputs land in `out/`: `_parts.dxf`, `_preview.svg`, `_bom.csv`, `_job.json`.
Units: set `"units": "in"` and every input is read in inches; the BOM
displays inches too.

## Run the tests

```bash
cd gadget
lua tests/run_tests.lua     # 1400 assertions
```

## Layout

```
src/najjar/         the core (pure Lua, no VCarve needed)
  json.lua            JSON codec (deterministic, \uXXXX -> UTF-8)
  merge.lua           deep merge powering defaults.json
  i18n.lua            EN/HE/AR translations, RTL flags
  spec.lua            spec defaults + validation (zones, dividers, boxes,
                      materials, fronts, sheet, hardware refs)
  rules.lua           construction rules -> dimensioned panels
  hardware.lua        data-driven drilling/groove placement
  geometry.lua        panels -> unique parts + layout + sheet estimate
  bom.lua             bill of materials -> CSV (Excel-safe, mm/in)
  dxf.lua             DXF R12 writer (POLYLINE/CIRCLE/TEXT per layer)
  svg.lua             styled preview
  layers.lua          the layer contract (name -> CAM operation)
  vectric.lua         Vectric adapter: mock backend today, real SDK in v0.6
  fs.lua              tiny file helpers (replaced by gadget SDK later)
hardware/*.json     HARDWARE LIBRARY — edit these, not the code
lang/*.json         UI strings EN / HE / AR — community translations welcome
templates/*.json    example specs: euro base, zoned wardrobe, mixed kitchen
vcarve/            THE GADGET SHELL - installable in VCarve/Aspire
release/           built NajjarPro.vgadget packages
defaults.json.example  copy to defaults.json for your shop baseline
tests/              unit tests + three golden fixtures
tools/              dev tooling (build-lua.sh builds a standalone Lua)
```

## The layer contract

| Layer | CAM operation |
|---|---|
| `CUT` | profile cut (tool offset on) |
| `DRILL5_SHELF` | drill Ø5 (shelf pins) |
| `DRILL_CABINEO` | drill Ø5 (connector) |
| `POCKET_CABINEO` | pocket Ø15 (connector) |
| `DRILL_HINGE` | drill Ø35 cup + Ø5.5 screws |
| `LED_GROOVE` | pocket the LED channel (top is flipped — see BOM) |
| `DRILL_SLIDE` | drill the slide locking pattern (hole + slot) |
| `DRILL5_SHELF_FLIP` | shelf pins for the opposite face (flip the part) |
| `BOX_GROOVE` | pocket the drawer-bottom groove (grooved boxes) |
| `DRILL_DOWEL` | drill box corner joinery (dowel / rafix face holes) |
| `ETCH` | V-bit engrave (labels, cabinet marks) |

## Golden references (asserted in tests)

**1) Euro base 900×720×560, t18, grooved back, 2 shelves** — 5 unique
parts: sides 560×720, bottom/top 864×541, back 880×720, shelves 862×550;
40 pins + 8 Cabineo features per side; 3.32 m².

**2) Wardrobe 1000×2000×550, door zone + drawer zone** — 8 unique parts
/ 14 total: doors 496.5×1596 with 3 hinges each (mirrored), fronts
996×130, shelves t16; 120 pins per side; 9.23 m².

**4) Kitchen-job — 3 cabinets in one project** (K1 + two identical wall
cabinets 600×700×520): 19 unique parts / 38 total — identical cabinets
merge (4 wall sides in one row), 10.97 m² → 4 sheets, deterministic
project-wide pipeline.

**3) Kitchen-mixed 900×900×550, divider at 300 + boxes + slides + LED** —
13 unique parts / 24 total: divider 531×682 standing ON the bottom panel
(84 machining ops: 40 pins + 40 flip pins + 4 Cabineo; bottom panel drilled
at the divider line), per-bay shelves 289/553 wide, drawer boxes with
undermount locking (rear Ø10 + front slot per side), LED groove on the
flipped top; 6.17 m² → 3 sheets.

## ⚠ Verify before cutting

Hardware dimensions are **engineering defaults pending catalog sign-off**
(see the `"verify"` field in every `hardware/*.json`). Hinge cup inset
(22 mm), end margin (100 mm), drawer-box clearances (13 mm/side) and the
LED channel position are parametric — set them to your brands' values.
**No production cutting until a real part has been test-machined and
signed off.**

## Known simplifications

- Slide locking positions are generic defaults — set them to your brand
  (Blum / Hettich / generic) in `hardware/slide_undermount.json`.
- Drawer-box corner joinery (dowels / rafix) arrives in v0.5.
- Back groove corner geometry is the classic full-height method.

## Roadmap

v1.0: licensing (offline keys, trial mode) + website — after the
live VCarve first-run (needs a license).
See [`CHANGELOG.md`](CHANGELOG.md) for the full version history and the
product plan for the business model.
